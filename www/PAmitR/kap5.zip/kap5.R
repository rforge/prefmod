###################################################
### chunk number 1: 
###################################################
library(gnm)
library(prefmod)
library(ggplot2)

# Daten einlesen
D_orig <- read.table('kap5.csv',sep=';',header=TRUE,na.strings='.')

# Personen die die Conjoint nicht ausgef�llt haben heruasnehmen
D_orig<-D_orig[!is.na(D_orig[,1]),]

# Datenfehler eliminieren
D_orig <- D_orig[-which(D_orig$F_7 ==6),]


# umbenennen
D<-D_orig


#ein paar Definitinen
ncards= 8               #Anzahl der K�rtchen definieren
ind =0          # eine Indexvaraible, aus rein technischen Gr�nden
compnames<-c()  # hier werdne die NAmen der Vergeliche gespeichert

# in die Matrix m werden die umgewandelten gespeichert
m<- matrix(data =NA, nrow=dim(D)[1], ncol = ncards*(ncards-1)/2)


# Die Daten von Bewertungen in Parvergleich umwandeln
for( j in 2:ncards)
{
        for(i in 1:(j-1))
        {
                ind =ind+1
                s=paste("comp",i,j,sep="")
                compnames <- cbind(compnames,s)

                # die indizes bestimmen, ob jeweils das erst oder das zweite objekt gew�hlt wurde
                ind_Ki_choosen <- D[,i]< D[,j] # objekt i besser bewertert => das i-te gew�hlt
                ind_undecided <- D[,i]== D[,j] # beiden objek gleich bewertet => keine Entscheidung
                ind_Kj_choosen <- D[,i]> D[,j] # objekt j besser bewertert => das j-te gew�hlt

                # Die daten richitg kodieren
                m[ind_Ki_choosen,ind] = 0 # i-tes objekt gew�hlt
                m[ind_undecided,ind] = 1 # indifferent
                m[ind_Kj_choosen,ind] = 2 # j-tes Objekt gew�hlt
        }
}


# Paarvergelichsdaten mit restlichen Daten zusammenf�hren
dm<-cbind(m,D)


#dim(dm) #Spalten und Zeilen Summary
#names(dm) #redundante Zeilen �berpr�fen

dm$K1 <- NULL
dm$K2 <- NULL
dm$K3 <- NULL
dm$K4 <- NULL
dm$K5 <- NULL
dm$K6 <- NULL
dm$K7 <- NULL
dm$K8 <- NULL

# ENDE: Datenaufbereitung

# Definition einer plotfunktion
plotpref<-function(x, main="Preferences", xlab="Groups", ylab="Estimate")
{
     x<-x[order(x$group,-x$estimate),]
     group<-factor(x$group)
     tab<-table(group)
     x$group<-group
     hadj0<-rep(c(-0.7,1.6),ceiling(tab[1]/2),length.out=tab[1])
     hadj<-rep(hadj0,length(tab))
     x<-cbind(x,hadj)
     p<-qplot(group, estimate, colour=objects, data=x,
               main=main, xlab=xlab, ylab=ylab)
     p$legend.position="none"
     psize<-geom_point(size=3)

     ann<-geom_text(aes(x=group,y=estimate,label=objects,colour=objects), hjust=hadj,size=3)
     print(p+psize+ann)
}

###############################################
#
#               Objekt Parameter
#
###############################################

#----------------------------------
# ----    Daten aufbereiten     ---
#----------------------------------


# mit dem prefmod package die Matrix richtig erstellen
des_obj_comps <- llbt.design(dm, nitems = 8)

# Die ersten Zeilen der Matrix ausgeben
head(des_obj_comps)

#----------------------------------
# ---- berechnen der lambda_i^O ---
#----------------------------------

#  --- ohne No Option --
# Die Sch�tzung durchf�hren
res_obj_comps2 <- gnm(y ~ o1 + o2 + o3 + o4+ o5 + o6 + o7 + o8, eliminate = mu, data = des_obj_comps,family = poisson)
#ergebnis anzeigen
summary(res_obj_comps2)

# --- Mit No Option --
#Sch�tzung durchf�hren
res_obj_comps <- gnm(y ~ o1 + o2 + o3 + o4+ o5 + o6 + o7 + o8 + g1, eliminate = mu, data = des_obj_comps,family = poisson)

#Das Ergbnis der Sch�tzung f�r die Objektparameter

summary(res_obj_comps)

#----------------------------------
# ---- berechnen der pi_i       ---
#----------------------------------


#objekte Erkl�rung: bei 8 Objekten gibt es (8*7)/2 Vergleiche;
# das ergibt 28 und die Objekte sind somit auf Platz [29:36]
res_obj_comps$coefficients[36] <- 0
worth <- round(exp(2 * res_obj_comps$coefficients[29:36])/(sum(exp(2 *res_obj_comps$coefficients[29:36]))), digits = 4)
names(worth) <- paste("pi", 1:ncards, sep = "")
print(worth)

#----------------------------------
# ---- Ergebnmis plotten      ---
#----------------------------------

# Daten aufbereiten, die plotpref funktin ben�tigt spezeille Namen
group<-rep(c("Gesamtmarkt"),8)
estimate<-worth
objects<-names(worth)

x<-data.frame(estimate,objects,group)
plotpref(x,xlab="",main="Worth Parameter")

###############################################
#
#               Subjekt Kovariaten
#
###############################################


#----------------------------------
# ----    Daten aufbereiten     ---
#----------------------------------


#Subjekt_Kovariaten

# Hat die Dauer einen Einfluss? (Wie lange man shcon bei dem jetzigne Netzbetreiber ist

# Eine MAtrix erstellen die in den ersten 28 Spalten die Paarvergleich hat und in der 29 ten die Subjekt Kovariate
dm5<-dm[-c(29:49,51:94)]

names(dm5)

# mit dem preofmod package die Matrix f�r die Sch�tzung erstellen
des_subj5 <- llbt.design(dm5, nitems = 8, cov.sel=c("F_7"))

# die daur als faktor definieren
dauer<-factor(des_subj5$F_7)

names(des_subj5)

#----------------------------------
# ----  lambdas berechnen         ---
#----------------------------------

#Sch�tzung durchf�hren
res_subj5<-gnm(y~o1+o2+o3+o4+o5+o6+o7+o8+g1+(o1+o2+o3+o4+o5+o6+o7+o8):dauer, eliminate =mu:dauer, data=des_subj5, family=poisson)


res_subj7<-gnm(y~o1+o2+o3+o4+o5+o6+o7+o8+g1, eliminate =mu:dauer, data=des_subj5, family=poisson)
summary(res_subj7)


anova(res_subj5,res_subj7)
1-pchisq(95.53,28)


#Ergebnis anzeigen
summary(res_subj5)


# die index vektoren bestimmen mit denen man die Paramter o1, dauer2:o2, dauer3:o2 usw herauslesen kann
ind_o1<-c(c("o1"),paste(paste(c("dauer"),2:5,sep=""),rep(c("o1"),3),sep=":"))
ind_o2<-c(c("o2"),paste(paste(c("dauer"),2:5,sep=""),rep(c("o2"),3),sep=":"))
ind_o3<-c(c("o3"),paste(paste(c("dauer"),2:5,sep=""),rep(c("o3"),3),sep=":"))
ind_o4<-c(c("o4"),paste(paste(c("dauer"),2:5,sep=""),rep(c("o4"),3),sep=":"))
ind_o5<-c(c("o5"),paste(paste(c("dauer"),2:5,sep=""),rep(c("o5"),3),sep=":"))
ind_o6<-c(c("o6"),paste(paste(c("dauer"),2:5,sep=""),rep(c("o6"),3),sep=":"))
ind_o7<-c(c("o7"),paste(paste(c("dauer"),2:5,sep=""),rep(c("o7"),3),sep=":"))
ind_o8<-c(c("o8"),paste(paste(c("dauer"),2:5,sep=""),rep(c("o8"),3),sep=":"))

# die lambda_ij^OS bestimmen
o1_sub<-res_subj5$coefficients[ind_o1]          # = lambda_1^O, lambda_12^OS, lambda_13^OS  ...
o2_sub<-res_subj5$coefficients[ind_o2]          # = lambda_2^O, lambda_22^OS, lambda_23^OS  ...
o3_sub<-res_subj5$coefficients[ind_o3]          # = lambda_3^O, lambda_32^OS, lambda_33^OS  ...
o4_sub<-res_subj5$coefficients[ind_o4]  # = lambda_4^O, lambda_42^OS, lambda_43^OS  ...
o5_sub<-res_subj5$coefficients[ind_o5]
o6_sub<-res_subj5$coefficients[ind_o6]
o7_sub<-res_subj5$coefficients[ind_o7]
o8_sub<-rep(0,length(ind_o1)) # das object 8 auf 0 setzen

# Die Effekte der einzelnen Levels zum Referenz level hinzu addeieren
o1_sub[-1]=o1_sub[-1]+o1_sub[1]
o2_sub[-1]=o2_sub[-1]+o2_sub[1]
o3_sub[-1]=o3_sub[-1]+o3_sub[1]
o4_sub[-1]=o4_sub[-1]+o4_sub[1]
o5_sub[-1]=o5_sub[-1]+o5_sub[1]
o6_sub[-1]=o6_sub[-1]+o6_sub[1]
o7_sub[-1]=o7_sub[-1]+o7_sub[1]
o8_sub[-1]=o8_sub[-1]+o8_sub[1]



#----------------------------------
# ----  Ergebnis plotten          ---
#----------------------------------

# die vektoren f�r die plotpref Funktion erzeugen
estimates<-c()
for(i in 1:length(ind_o1))
{
        estimates<-c(estimates,o1_sub[i])
        estimates<-c(estimates,o2_sub[i])
        estimates<-c(estimates,o3_sub[i])
        estimates<-c(estimates,o4_sub[i])
        estimates<-c(estimates,o5_sub[i])
        estimates<-c(estimates,o6_sub[i])
        estimates<-c(estimates,o7_sub[i])
        estimates<-c(estimates,o8_sub[i])
}


# die Namen der Levels
group_strings_extended<-c(rep("0 bis 3 Monate",8),rep("3 bis 6 Monate",8),rep("6 bis 12 Monate",8),rep("1 bis 2 Jahre",8),rep("l�nger als 2 Jahre",8))

#die Obejkt name
objects_names = rep(paste(c("o"),1:8,sep=""),5)

# die plotpref Funktion ben�tigt spezielle Namen
estimate<-estimates
objects<-objects_names
group<-group_strings_extended

x<-data.frame(estimate,objects,group)

plotpref(x,xlab="Zeit, seit wann man bei seinem derzeitigen Netzbetreiber ist",ylab="Estimates")

###############################################
#
#               Subjekt- Subjekt Interaktion
#
###############################################

# F_7 verweildauer beim Netzbetreiber
# F_8 ob man den Vertrag selbst entscheiden hat

#M�gliche Subjekt-Subjekt-Interaktion:
#Entscheidung selbst getroffen?

# w�hle nur die Paarvergleichsspalten
dm6<-dm[-c(29:49,52:94)]

# Daten umkodieren und eine neue Spalte f�r die umkodierte Varaible machen F_8
dm6$rec_F8 <- factor (ifelse(dm6$F_8==1,1,2))

# die letze Spalte wieder wegnehemen
dm6<-dm6[,-30]

#dm6 <- dm6[which(dm6[,1] <6),]

des_subj6 <- llbt.design(dm6, nitems = 8, cov.sel=c("F_7","rec_F8"))
dauer<-factor(des_subj6$F_7)
entsch<-factor(des_subj6$rec_F8)

res_subj6<-gnm(y~o1+o2+o3+o4+o5+o6+o7+o8+g1+(o1+o2+o3+o4+o5+o6+o7+o8):dauer+entsch:dauer, eliminate =mu:dauer, data=des_subj6, family=poisson)


# wechselwirkungsmodell
res_subj8<-gnm(y~o1+o2+o3+o4+o5+o6+o7+o8+g1+(o1+o2+o3+o4+o5+o6+o7+o8):(dauer:entsch), eliminate =mu:dauer:entsch, data=des_subj6, family=poisson)

# 2 haupteffektmodell
res_subj8<-gnm(y~o1+o2+o3+o4+o5+o6+o7+o8+g1+(o1+o2+o3+o4+o5+o6+o7+o8):(dauer+entsch), eliminate =mu:dauer:entsch, data=des_subj6, family=poisson)



summary(res_subj8)

###############################################
#
#               Objekt Kovariaten
#
###############################################

#----------------------------------
# ----    Daten aufbereiten     ---
#----------------------------------

# Die Eigenschaften der einzelnen K�rtchen definieren

dummy_PER20     <-c(0,0,0,0,1,1,0,0)
dummy_PER30     <-c(0,1,1,0,0,0,0,0)
dummy_WZ        <-c(0,0,1,1,1,0,1,0)
dummy_WV        <-c(0,0,1,1,1,0,0,1)
res_subj8<-gnm(y~o1+o2+o3+o4+o5+o6+o7+o8+g1+(o1+o2+o3+o4+o5+o6+o7+o8):(dauer:entsch), eliminate =mu:dauer:entsch, data=des_subj6, family=poisson)

res_subj8<-gnm(y~o1+o2+o3+o4+o5+o6+o7+o8+g1+(o1+o2+o3+o4+o5+o6+o7+o8):(dauer:entsch), eliminate =mu:dauer:entsch, data=des_subj6, family=poisson)

res_subj8<-gnm(y~o1+o2+o3+o4+o5+o6+o7+o8+g1+(o1+o2+o3+o4+o5+o6+o7+o8):(dauer:entsch), eliminate =mu:dauer:entsch, data=des_subj6, family=poisson)

res_subj8<-gnm(y~o1+o2+o3+o4+o5+o6+o7+o8+g1+(o1+o2+o3+o4+o5+o6+o7+o8):(dauer:entsch), eliminate =mu:dauer:entsch, data=des_subj6, family=poisson)



OBJ<-as.matrix(des_obj_comps [,6:13])
PER20 <- OBJ %*% dummy_PER20
PER30 <- OBJ %*% dummy_PER30
WZ <- OBJ %*% dummy_WZ
WV <- OBJ %*% dummy_WV

# Anmerkung: Verwende dummy kodierung

#----------------------------------
# ----    Die Betas berechnen   ---
#----------------------------------

# Berechnung durchf�hren
res_ovj_covs<-gnm(y~PER20+PER30 + WZ + WV+g1,eliminate=mu,data=des_obj_comps,family=poisson)

# Ergebnis anzeigen
summary(res_ovj_covs)

#----------------------------------
# ----    Ergebnis plotten        ---
#----------------------------------

# -- Die beats rauslesen und f�r jedes Attribut in einen eigenen Vektor schreiben

# (0, beta_PER20, beta_PER30 )
beta_Prozent<-c(0,res_ovj_covs$coefficients[29],res_ovj_covs$coefficients[30])

# (0, beta_WZ )
beta_WeiterzahlungGrundgebuehr<-c(0,res_ovj_covs$coefficients[31])

# (0, beta_WV )
beta_WeiterverwendungNummer<-c(0,res_ovj_covs$coefficients[32])

# Die Namen der einzelnen Auspr�gungen definieren
s1<-c("10 Prozent","20 Prozent","30 Prozent")
s2<-c("keine Weiterzahlung","Weiterzahlung")
s3<-c("kein Mitnahme","Mitnahme")
# Die Namen der Attribute definieren
names_attributes<-c("Erh�hung der Preise","Weiterzahlung der Grundgeb�hr","Rufnummernmitnahme")

# daten und namen aggregieren
beta_list <-list(beta_Prozent,beta_WeiterzahlungGrundgebuehr,beta_WeiterverwendungNummer)
names_list <-list(s1,s2,s3)


n_attributes = length(beta_list) # anzahl der attribute
par(mfrow = c(1,n_attributes)) # mehrer plots in einer figure anzeigen

# Faktoren zum anzeigen
max_val=max(sapply(beta_list,max))
min_val=min(sapply(beta_list,min))
border_factor =1.1;

# Schleife �ber alle Attribute (Erh�hunhg der Preise, Weiterzahlung Grundgeb�hr, Rufnumernmitnahme)
for(i in 1:n_attributes)
{
        # Balken zeichnen
      mp<-barplot(beta_list[[i]],ylim=c(min_val*border_factor,max_val*border_factor),
   ylab="Estimate",xlab="",names.arg=rep(c(""),length(beta_list[[i]])))

       title(sub=names_attributes[i],cex.sub=2) # titel hinzuf�gen
       text(mp,rep(0,length(mp)),names_list[[i]],adj = c(1,0)
        ,srt = 90
        ,offset =-35
        ,cex=1.5) # Text in Balken hinzuf�gen

}


###################################################
#
#               Objekt - Subjekt Kovariaten Kovariaten
#
###################################################


#----------------------------------
# ----    Daten aufbereiten     ---
#----------------------------------


#des_subj5 <- llbt.design(dm5, nitems = 8, cov.sel=c("F_7"))

dauer<-factor(des_subj5$F_7)
#names(des_subj5)

OBJ<-as.matrix(des_subj5 [,6:13])

PER20 <- OBJ %*% dummy_PER20
PER30 <- OBJ %*% dummy_PER30
WZ <- OBJ %*% dummy_WZ
WV <- OBJ %*% dummy_WV


#----------------------------------
# ---- betas sch�tzen           ---
#----------------------------------

#Sch�tzung durchf�hren
res_subj_obj<-gnm(y~PER20+PER30 + WZ + WV+g1+(PER20+PER30 + WZ + WV):dauer, eliminate =mu:dauer, data=des_subj5, family=poisson)

#ergebnis anzeigen
summary(res_subj_obj)



#----------------------------------
# ---- Ergebnis plotten                 ---
#----------------------------------
#index vektoren bestimmen
ind_PER20<-c(c("PER20"),paste(paste(c("dauer"),2:5,sep=""),rep(c("PER20"),3),sep=":"))
ind_PER30<-c(c("PER30"),paste(paste(c("dauer"),2:5,sep=""),rep(c("PER30"),3),sep=":"))
ind_WV<-c(c("WV"),paste(paste(c("dauer"),2:5,sep=""),rep(c("WV"),3),sep=":"))
ind_WZ<-c(c("WZ"),paste(paste(c("dauer"),2:5,sep=""),rep(c("WZ"),3),sep=":"))

# die Daten aus den Koeffiziente herauslesen
beta_PER20_dauer<- res_subj_obj$coefficients[ind_PER20]         # beata_1, beta_12^S, beta_13^S, ...
beta_PER30_dauer<- res_subj_obj$coefficients[ind_PER30]         # beata_2, beta_22^S, beta_23^S, ...
beta_WZ_dauer<- res_subj_obj$coefficients[ind_WZ]               # beata_3, beta_32^S, beta_33^S, ...
beta_WV_dauer<- res_subj_obj$coefficients[ind_WV]               # beata_4, beta_42^S, beta_43^S, ...

# zum Grundlevel die Effekte des jeweiligen Levels dazuaddieren
beta_PER20_dauer[2:length(beta_PER20_dauer)]=beta_PER20_dauer[2:length(beta_PER20_dauer)]+beta_PER20_dauer[1]
beta_PER30_dauer[2:length(beta_PER30_dauer)]=beta_PER30_dauer[2:length(beta_PER30_dauer)]+beta_PER30_dauer[1]

beta_WZ_dauer[2:length(beta_WZ_dauer)]=beta_WZ_dauer[2:length(beta_WZ_dauer)]+beta_WZ_dauer[1]
beta_WV_dauer[2:length(beta_WV_dauer)]=beta_WV_dauer[2:length(beta_WV_dauer)]+beta_WV_dauer[1]

beta_list <-cbind(rep(0.0,5),beta_PER20_dauer,beta_PER30_dauer,beta_WZ_dauer,beta_WV_dauer)


# Namen vergeben
s1<-c("10 Prozent","20 Prozent","30 Prozent")
s2<-c("keine Weiterzahlung","Weiterzahlung")
s3<-c("kein Mitnahme","Mitnahme")
names_attributes<-c("Erh�hung der Preise","Weiterzahlung der Grundgeb�hr","Rufnummernmitnahme")
colnames(beta_list)<-c("","Erh�hung der Preise","", "Weiterzahlung der Grundgeb�hr","Rufnummernmitnahme")
names_list <-list(s1,s2,s3)
group_strings<-c("0 bis 3 Monate","3 bis 6 Monate","6 bis 12 Monate","1 bis 2 Jahre","l�nger als 2 Jahre")

# umschalten, damit wieder nur einplot in der figure zu shene ist
par(mfrow = c(1,1))

#  Balken plotten
mp<-barplot(beta_list,beside=T,col =gray.colors(5),ylab=c("Einfluss") )

#Titel hinzuf�gen
title(main=c("Einfluss der Objekt Kovariaten\nEingeteilt wie lange man schon bei seinem derzeitigem Betreiber ist"))

#legende hinzuf�gen
legend(mp[17],-0.2,group_strings,col =gray.colors(5),fill=gray.colors(5),title=c("Gruppen"))

text(mp[3],0.05,c("10 Prozent"),adj=c(0.5,0))
text(mp[3+5],0.05,c("20 Prozent"),adj=c(0.5,0))
text(mp[3+10],0.05,c("30 Prozent"),adj=c(0.5,0))



