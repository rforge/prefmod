###################################################
### chunk number 1:
###################################################
options(width=55)


###################################################
### chunk number 2:
###################################################
rm(list=ls(all=TRUE))
library(prefmod)
library(gnm)
#### transform excel data set to our data.frame ###
## read excel in R
##require (RODBC)
##z <- odbcConnectExcel2007(file.choose())
##umfrage <- sqlFetch(z,"28Juli")
umfrage<-read.csv("kap6.csv",header=TRUE)
##close(z)
attach(umfrage)


###################################################
### chunk number 3:
###################################################
## select the pc data and the subject covariates
umfrage_pc <- umfrage[6:33]
for(i in 1:dim(umfrage_pc)[2]) {nam <- as.numeric(unlist(strsplit(names(umfrage_pc)[i],split=""))[2:3]); umfrage_pc[,i][which(nam[2] == umfrage_pc[,i])] <- -1; umfrage_pc[,i][which(nam[1] == umfrage_pc[,i])] <- 0}

pc_data_xls  <- abs(umfrage_pc)
a <- c(1,9,5,13,10,2,19,25,24,6,23)
d <- c(18,20,15,3,26,28,16,21,11,7,8,22,27,17,14,12,4)
e <- c(a,d)
pc_data <- as.matrix(pc_data_xls [e])
subj <- umfrage[c(2:5,34,35)]
subj1 <- subj + 1
b <- c("wirtschaft", "kapitalmarkt", "vermoegen", "betrag", "alter", "familie")
names(subj1) <- b
complete <- cbind(pc_data,subj1)
comp <- as.data.frame(complete)


###################################################
### chunk number 4:
###################################################
des1 <- llbt.design(comp,nitems=8)
m1<-gnm(y~o1+o2+o3+o4+o5+o6+o7+o8,eliminate=mu, family=poisson,data=des1)


###################################################
### chunk number 5:
###################################################
m1$coefficients[36] <- 0


###################################################
### chunk number 6:
###################################################
### object covariates ###
## transformed (rows and colums) to * with design matrix
risiko_h <- c(0,0,0,1,1,1,1,0)
betrag_m <- c(1,0,0,1,0,0,0,0)
betrag_h <- c(0,1,0,0,0,1,0,0)
Laufz_k  <- c(1,0,1,0,0,1,1,0)
Rendit_h <- c(1,0,0,0,1,1,0,1)
obj <- cbind(risiko_h,betrag_h,betrag_m,Laufz_k,Rendit_h)

## design matrix %*% obj
#des1 <- llbt.design(comp,nitems=8)
new <-   as.matrix(des1[5:12]) %*% obj
newdes <- cbind(des1[,1:2],new)
m12 <- gnm(y~risiko_h+betrag_m+betrag_h+Laufz_k+Rendit_h, data=newdes, eliminate=mu, family=poisson)


###################################################
### chunk number 7:
###################################################
v <- anova(m1,m12)
print(1 - pchisq(abs(v[,4][2]),abs(v[,3][2])))
#### ist nich signifikant deshalb kann man dass modell mit objekt kovariaten reparametrisieren


###################################################
### chunk number 8:
###################################################
### subj. kovariaten auf 2 od. 3 auspr�gungen reduzieren um 3-fache wechselwirkungen zu berechnen
## alter transform to 1 2
subj_3 <- comp [33]
subj_3[subj_3==1|subj_3==2]<- 1
subj_3[subj_3==3|subj_3==4|subj_3==5]<- 2
comp[33] <- subj_3
## familie transform to 1,2 or 3 (weniger geht nicht da sonst nicht sinnvoll)
subj_4 <- comp [34]
subj_4[subj_4==3|subj_4==4]<- 3
comp[34] <- subj_4
## vermoegen transform to 1,2
subj_5 <- comp [31]
subj_5[subj_4==1|subj_4==2]<- 1
subj_5[subj_4==3|subj_4==4]<- 2
comp[31] <- subj_5


###################################################
### chunk number 9:
###################################################
des2 <- llbt.design(comp, nitems = 8, cov.sel = c("kapitalmarkt", "betrag", "alter"))
new2 <-   as.matrix(des2[5:12]) %*% obj
newdes2 <- cbind(des2[,1:2],new2,des2[,13:15])
subkov <- c("kapitalmarkt", "betrag", "alter")
nam <- array()
for(i in 1:length(subkov)) {
  j <- paste(c("newdes2","$",subkov[i]),collapse="")
  nam[i] <- paste("ver",i,sep=".")
  assign(nam[i], factor(eval(parse(text = j))))
}
ww3 <- gnm(y ~ (ver.1 * ver.2 * ver.3):(risiko_h + betrag_m + betrag_h + Laufz_k + Rendit_h), elim = mu:ver.1:ver.2:ver.3, family = poisson, data = newdes2)


###################################################
### chunk number 10:  eval=FALSE
###################################################
## ww2 <- gnm(y ~ (ver.1 * ver.2 + ver.1 * ver.3 + ver.2 * ver.3):(risiko_h + betrag_m + betrag_h + Laufz_k + Rendit_h), elim = mu:ver.1:ver.2:ver.3, family = poisson, data = newdes2)
## he <- gnm(y ~ (ver.1 + ver.2 + ver.3):(risiko_h + betrag_m + betrag_h + Laufz_k + Rendit_h), elim = mu:ver.1:ver.2:ver.3, family = poisson, data = newdes2)
## nm <- gnm(y ~ (1):(risiko_h + betrag_m + betrag_h + Laufz_k + Rendit_h), elim = mu:ver.1:ver.2:ver.3, family = poisson, data = newdes2)


###################################################
### chunk number 11:
###################################################
##Modell mit 2-facher Wechselwirkung
ww2 <- gnm(y ~ (ver.1 * ver.2 + ver.1 * ver.3 + ver.2 * ver.3):(risiko_h + betrag_m + betrag_h + Laufz_k + Rendit_h), elim = mu:ver.1:ver.2:ver.3, family = poisson, data = newdes2)
p <- anova(ww3,ww2)
## Goodness of fit - test
print(1-pchisq(abs(p[,4][2]),abs(p[,3][2])))
## das Modell kann reduziert werden
### nun betrachten wir alle Haupteffekte
he <- gnm(y ~ (ver.1 + ver.2 + ver.3):(risiko_h + betrag_m + betrag_h + Laufz_k + Rendit_h), elim = mu:ver.1:ver.2:ver.3, family = poisson, data = newdes2)
a <- anova(ww3,he)
## Goodness of fit - test
print(1-pchisq(abs(a[,4][2]),abs(a[,3][2])))
## das Modell kann reduziert werden
##nullmodell
nm <- gnm(y ~ (1):(risiko_h + betrag_m + betrag_h + Laufz_k + Rendit_h), elim = mu:ver.1:ver.2:ver.3, family = poisson, data = newdes2)
b <- anova(ww3,nm)
## Goodness of fit - test
print(1-pchisq(abs(b[,4][2]),abs(b[,3][2])))
## das modell kann nicht mehr reduziert werden wir nehmen das modell mit den Haupteffekten


###################################################
### chunk number 12:
###################################################
he12 <- gnm(y ~ (ver.1 + ver.2):(risiko_h + betrag_m +
  betrag_h + Laufz_k + Rendit_h), elim = mu:ver.1:ver.2:ver.3,
  family = poisson, data = newdes2)


###################################################
### chunk number 13:
###################################################
 a <- anova(he,he12)
## Goodness of fit - test
print(1-pchisq(abs(a[,4][2]),abs(a[,3][2])))
he13 <- gnm(y ~ (ver.1 + ver.3):(risiko_h + betrag_m + betrag_h + Laufz_k + Rendit_h), elim = mu:ver.1:ver.2:ver.3, family = poisson, data = newdes2)
a <- anova(he,he13)
## Goodness of fit - test
print(1-pchisq(abs(a[,4][2]),abs(a[,3][2])))
he23 <- gnm(y ~ (ver.2 + ver.3):(risiko_h + betrag_m + betrag_h + Laufz_k + Rendit_h), elim = mu:ver.1:ver.2:ver.3, family = poisson, data = newdes2)
a <- anova(he,he23)
## Goodness of fit - test
print(1-pchisq(abs(a[,4][2]),abs(a[,3][2])))
he1 <- gnm(y ~ (ver.1):(risiko_h + betrag_m + betrag_h + Laufz_k + Rendit_h), elim = mu:ver.1:ver.2:ver.3, family = poisson, data = newdes2)
a <- anova(he,he1)
## Goodness of fit - test
print(1-pchisq(abs(a[,4][2]),abs(a[,3][2])))
he2 <- gnm(y ~ (ver.2):(risiko_h + betrag_m + betrag_h + Laufz_k + Rendit_h), elim = mu:ver.1:ver.2:ver.3, family = poisson, data = newdes2)
a <- anova(he,he2)
## Goodness of fit - test
print(1-pchisq(abs(a[,4][2]),abs(a[,3][2])))
he3 <- gnm(y ~ (ver.3):(risiko_h + betrag_m + betrag_h + Laufz_k + Rendit_h), elim = mu:ver.1:ver.2:ver.3, family = poisson, data = newdes2)
a <- anova(he,he3)
## Goodness of fit - test
print(1-pchisq(abs(a[,4][2]),abs(a[,3][2])))
## he12 ist das modell mit dem besten ergebnis : => Kapitalmarkt + Betrag


###################################################
### chunk number 14:
###################################################
mlist<-list(he1,he2,he3,he12,he13,he23)
alist<-lapply(mlist,function(x)anova(ww3,x))
devdiff<-sapply(alist, function(x) x$Deviance[2])
dfdiff<-sapply(alist, function(x) x$Df[2])
pvec<- 1-pchisq(abs(devdiff),abs(dfdiff))
result.table<-cbind(devdiff,dfdiff,pvec)


###################################################
### chunk number 15:  eval=FALSE
###################################################
## la <- he1$coefficients[337:346]
## ostring<-c("Risiko\nhoch","notwendiger\nBetrag\nmittel","notwendiger\nBetrag\nhoch","Laufzeit\nkurz","Rendite\nhoch")
## barplot(la,widt=0.9,xlim=c(0,10),col=gray.colors(2),space=0.1,axisnames=FALSE, ylab="Parameter estimates")
## text(c(1,3,5,7,9),c(0.1,0.1,0.1,-0.1,-0.1)/2,ostring)
## group_strings<-c("positiv","negativ")
## legend(1, 0.3, group_strings, col = gray.colors(2), fill = gray.colors(2),title = c("Kapitalmarkt"))


###################################################
### chunk number 16:
###################################################
options(width=80)


