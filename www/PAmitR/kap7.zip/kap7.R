###################################################
### chunk number 1:
###################################################
options(width=55)


###################################################
### chunk number 2:
###################################################
library(prefmod)
patt3<-prefmod:::all_patterns(1,0,3)
patt3<-ifelse(patt3==0,-1,1)
rownames(patt3)<-rep("",8)
colnames(patt3)<-rep("",3)
#patt3


###################################################
### chunk number 3:
###################################################
options(width=80)


###################################################
### chunk number 4:
###################################################
rm(list=ls(all=TRUE))
library(prefmod)
dat<-read.table("kap7.dat",header=TRUE)
head(dat)


###################################################
### chunk number 5:
###################################################
options(width=55)


###################################################
### chunk number 6:  eval=FALSE
###################################################
## model.0<-pattR.fit(dat,nitems=6,formel=~1,elim=~SEX*ALTER*M.PREF)


###################################################
### chunk number 7:
###################################################
load("kap7models.Rdata")


###################################################
### chunk number 8:  eval=FALSE
###################################################
## model.0<-pattR.fit(dat,nitems=6,formel=~1,elim=~SEX*ALTER*M.PREF)


###################################################
### chunk number 9:
###################################################
model.0


###################################################
### chunk number 10:  eval=FALSE
###################################################
## model.1<-pattR.fit(dat,nitems=6,formel=~SEX+ALTER+M.PREF,elim=~SEX*ALTER*M.PREF)
## model.2<-pattR.fit(dat,nitems=6,formel=~SEX*ALTER+SEX*M.PREF+ALTER*M.PREF,elim=~SEX*ALTER*M.PREF)
## model.3<-pattR.fit(dat,nitems=6,formel=~SEX*ALTER*M.PREF,elim=~SEX*ALTER*M.PREF)


###################################################
### chunk number 11:
###################################################
#print(getOption("width"))
devdiff<- -2*(model.2$ll-model.3$ll)
npar3<-length(model.3$coefficients)
npar2<-length(model.2$coefficients)
df<-npar3-npar2
pval<-1-pchisq(devdiff,df)
c(devdiff,df,pval)


###################################################
### chunk number 12:  eval=FALSE
###################################################
## model.SA<-pattR.fit(dat,nitems=6,formel=~SEX+ALTER,elim=~SEX*ALTER*M.PREF)
## model.SM<-pattR.fit(dat,nitems=6,formel=~SEX+M.PREF,elim=~SEX*ALTER*M.PREF)
## model.AM<-pattR.fit(dat,nitems=6,formel=~ALTER+M.PREF,elim=~SEX*ALTER*M.PREF)


###################################################
### chunk number 13:
###################################################
devdiff2<- -2*(model.SM$ll-model.1$ll)
npar1<-length(model.1$coefficients)
nparSM<-length(model.SM$coefficients)
df2<-npar1-nparSM
pval2<-1-pchisq(devdiff2,df2)
c(devdiff2,df2,pval2)


###################################################
### chunk number 14:  eval=FALSE
###################################################
## model.SA


###################################################
### chunk number 15:  eval=FALSE
###################################################
## patt.worth(model.SA)


###################################################
### chunk number 16:
###################################################
wSA<-patt.worth(model.SA)
wSA


###################################################
### chunk number 17:  eval=FALSE
###################################################
## plotworth(wSA)


###################################################
### chunk number 18:  eval=FALSE
###################################################
## model.S<-pattR.fit(dat,nitems=6,formel=~SEX,elim=~SEX*ALTER*M.PREF)
## wS<-patt.worth(model.S)
## plot.worth(wS)


###################################################
### chunk number 19:
###################################################
options(width=80)


