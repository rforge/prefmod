library(prefmod)
mdat <- read.table("kap9.dat", h = T)
head(mdat)
m1 <- pattLrep.fit(mdat, 4, 2, ia = T, iaT = T,
    formel = ~LOY, undec = T, pr.it = T)
m2 <- pattLrep.fit(mdat, 4, 2, ia = T, iaT = T,
    elim = ~LOY, undec = T, pr.it = T)
m3 <- pattLrep.fit(mdat, 4, 2, ia = T, iaT = F,
    formel = ~LOY, undec = T, pr.it = T)
m4 <- pattLrep.fit(mdat, 4, 2, ia = F, iaT = T,
    formel = ~LOY, undec = T, pr.it = T)
devdiff1 <- -2 * (m2$ll - m1$ll)
devdiff2 <- -2 * (m3$ll - m1$ll)
devdiff3 <- -2 * (m4$ll - m1$ll)
npar1 <- length(m1$coefficients)
npar2 <- length(m2$coefficients)
npar3 <- length(m3$coefficients)
npar4 <- length(m4$coefficients)
df1 <- npar1 - npar2
df2 <- npar1 - npar2
df3 <- npar1 - npar4
prob1 <- 1 - pchisq(devdiff1, df1)
prob2 <- 1 - pchisq(devdiff2, df2)
prob3 <- 1 - pchisq(devdiff3, df3)
print(prob1)
print(prob2)
print(prob3)
m1
patt.worth(m1)
plotworth(patt.worth(m1))
