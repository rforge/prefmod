###################################################
### chunk number 1:
###################################################
##### Laden des Datensatzes und Aufbereitung #####################
##### l�uft im Hintergrund! ######################################
##################################################################
### Clear your workspace #########################################
rm(list=ls(all=TRUE))
##################################################################
##################### Diverse Funktionen #########################
llbt.plot<-function(resultat,item=8,wert=TRUE,beschr=NULL,mltp=1,oj=NULL, titel = "Preferences"){
length(resultat)->k
out=c()
if (mltp!=1){
for (l in mltp:1) {
aufbereitung(resultat,n=item, val=FALSE,d=beschr[[l]],p=mltp,u=l,obj=oj)->hilf2
out<-cbind(hilf2,out)
}
for (i in 2:dim(out)[2]) out[,1]+out[,i]->out[,i]
apply(out,2,worth)->out
} else {
for (i in 1:k){
if (!is.null(beschr)) bez<-beschr[[i]] else FALSE->bez
aufbereitung(resultat[[i]],n=item,d=bez,obj=oj)->hilf2
out<-cbind(out,hilf2)
}
}
plotworth(out,main=titel)
}

worth<-function(s){s<-exp(2*s)/ sum(exp(2*s))}

aufbereitung<-function(x,n=8,val=TRUE,d=FALSE,p=1,u=1,obj=NULL){
if (!is.null(obj)) o<-obj else o<-n
p*choose(n,2)+(u-1)*o+u-1->hilfs
x$coefficients[(hilfs+1):(hilfs+o)]->s
s[o]<-0.0000
names(s)=NULL
if (val) s<-exp(2*s)/ sum(exp(2*s))
as.matrix(s)->s
rownames(s)<-names(x$coefficients[(hilfs+1):(hilfs+o)])
if (d==FALSE) d<-LETTERS[1:dim(s)[2]]
colnames(s)<-d
output<-s
}
##################################################################
### Laden der ben�tigten Pakete und Daten inkl Aufbereitung #######
library(prefmod)
library(gnm)
#library(ggplot2)
#library(xtable)
#source("funktion.r")
read.table("kap4.csv",sep="\t", header=TRUE)->daten
# alle Hilfsfunktionen
daten[,1]->ageschl
daten[,2]->ada
daten[,3]->ama
daten[,32]->pda
daten[,33]->pma

# datenaufbereitung
assis<-cbind(daten[,65:92],ageschl, ada, ama) # Mitarbeiter -> Mitarbeiter
profs<-cbind(daten[,34:61],pda, pma)    # Prof -> Mitarbeiter
profs<-(profs[-c(28:80),])    # Zeilenkorrektur
###################################################################
########### profs u assis inkl subjektspez. Kovariaten ############
###################################################################


###################################################
### chunk number 2:
###################################################
des1<-llbt.design(assis,nitems=8)
names(des1)[6:13]<-c("FAKO","VERL","WIFO","KREA","KOOP","EHVE","GEGE","INMO")
res1<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO,eliminate=mu,data=des1,family=poisson)
des2<-llbt.design(profs,nitems=8)
names(des2)[6:13]<-c("FAKO","VERL","WIFO","KREA","KOOP","EHVE","GEGE","INMO")
res2<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO,eliminate=mu,data=des2,family=poisson)
rev(res1$coefficients)[1:8]->coef_res1
coef_res1[1]<-0
rev(res2$coefficients)[1:8]->coef_res2
coef_res2[1]<-0
worth(coef_res1)->h1
worth(coef_res2)->h2


###################################################
### chunk number 3:
###################################################
#llbt.plot(list(res1,res2),beschr=c("Assistenten","Professoren"))
plot(sort(h1),h2[order(h1)],pch=16,xlab="Vermutung der Assistenten �ber Erwartung",ylim=c(0.02,0.24),ylab="Erwartungen der Professoren")
title("Preferences")
text(sort(h1),h2[order(h1)]+0.01,labels=c("KREA","","","","GEGE","","WIFO",""),pos=4)
abline(0,1,lty="dashed")


###################################################
### chunk number 4:
###################################################
res1un<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1,eliminate=mu,data=des1,family=poisson)
res2un<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1,eliminate=mu,data=des2,family=poisson)


###################################################
### chunk number 5:
###################################################
llbt.plot(list(res1un,res2un),beschr=c("Assistenten","Professoren"))


###################################################
### chunk number 6:
###################################################
des1_geschl<-llbt.design(assis,nitems=8, cov.sel=c("ageschl"))
sex<-factor(des1_geschl$ageschl)
names(des1_geschl)[6:13]<-c("FAKO","VERL","WIFO","KREA","KOOP","EHVE","GEGE","INMO")
res1_geschl<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1+(FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1):sex,eliminate=mu:sex,data=des1_geschl,family=poisson)
res1<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1,eliminate=mu:sex,data=des1_geschl,family=poisson)
coefs1_geschl<-rev(res1_geschl$coefficients)[1:18]
coefs1_geschl<-coefs1_geschl[-c(1,10)]
coefs1_geschl[c(1,9)]<-0
maen<-rev(coefs1_geschl)[1:8]
weibl<-rev(coefs1_geschl[1:8])+maen
names(weibl)<-names(maen)
fem<- worth(weibl)
masc<-worth(maen)


###################################################
### chunk number 7:
###################################################
#llbt.plot(res1_geschl,wert=FALSE,beschr=c("m�nnlich","weiblich"),mltp=2,titel="Preferences - Assistenten")
plot(sort(fem),rev(worth(coef_res2))[order(fem)],pch=16,xlab="Assistenten/Assistentinnen",xlim=c(0,0.28),ylim=c(0,0.28),ylab="Professoren")
text(sort(fem),rev(worth(coef_res2))[order(fem)],labels=c("KREA","","","","GEGE","","WIFO",""),pos=1)
points(masc[order(fem)],rev(worth(coef_res2))[order(fem)],pch=17)
text(masc[order(fem)],rev(worth(coef_res2))[order(fem)],labels=c("KREA","","","","GEGE","","WIFO",""),pos=4)
legend(0,0.27,c("Assistentinnen ~ Professoren","Assistenten ~ Professoren"),pch=c(16,17))
title("Preferences")
abline(0,1,lty="dashed")


###################################################
### chunk number 8:
###################################################
des1_da<-llbt.design(assis,nitems=8, cov.sel=c("ada"))
da<-factor(des1_da$ada)
names(des1_da)[6:13]<-c("FAKO","VERL","WIFO","KREA","KOOP","EHVE","GEGE","INMO")
res1_da<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1+(FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1):da,eliminate=mu:da,data=des1_da,family=poisson)
summary(res1_da)
coefs1_da<-rev(res1_da$coefficients)[1:27]
coefs1_da<-coefs1_da[-c(1,2,19)]
coefs1_da[c(1,2,17)]<-0
da1<-rev(coefs1_da)[1:8]
da2<-rev(coefs1_da[seq(2,16,by=2)])+da1
da3<-rev(coefs1_da[seq(1,16,by=2)])+da1
da1;da2;da3
names(da2)<-names(da1);names(da3)<-names(da1)
da1<-worth(da1)
da2<-worth(da2)
da3<-worth(da3)
x<-1:8
### dienstalter professoren mitarbeitereinsch�tzung ######################
des2_da<-llbt.design(profs,nitems=8, cov.sel=c("pda"))
da<-factor(des2_da$pda)
names(des2_da)[6:13]<-c("FAKO","VERL","WIFO","KREA","KOOP","EHVE","GEGE","INMO")
res2_da<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1+(FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1):da,eliminate=mu:da,data=des2_da,family=poisson)
summary(res2_da)
coefs2_da<-rev(res2_da$coefficients)[1:27]
coefs2_da<-coefs2_da[-c(1,2,19)]
coefs2_da[c(1,2,17)]<-0
da21<-rev(coefs2_da)[1:8]
da22<-rev(coefs2_da[seq(2,16,by=2)])+da21
da23<-rev(coefs2_da[seq(1,16,by=2)])+da21
names(da22)<-names(da21);names(da23)<-names(da21)
da21<-worth(da21);da22<-worth(da22);da23<-worth(da23)
range(da21);range(da22);range(da23)
x<-1:8


###################################################
### chunk number 9:
###################################################
plot(x,sort(da1),ylab="Estimates",xlab="Pers�nlichkeitseigenschaften",ylim=c(0.01,0.4),xaxt="n",type="l")
points(x,sort(da1),pch=1)
axis(1,at=1:8,labels=names(sort(da1)))
title("Einsch�tzung der Assistenten je nach Dienstalter")
lines(x,da2[order(da1)],lty=3)
points(x,da2[order(da1)],pch=16)
lines(x,da3[order(da1)],lty=5)
points(x,da3[order(da1)],pch=17)
legend(1,0.4,c("<5 J","5-12 J",">12 J"),pch=c(1,16,17),lty=c(1,3,5))


###################################################
### chunk number 10:
###################################################
plot(x,sort(da21),ylab="Estimates",xlab="Pers�nlichkeitseigenschaften",ylim=c(0,0.35),xaxt="n",type="l")
points(x,sort(da21),pch=1)
axis(1,at=1:8,labels=names(sort(da21)))
title("Einsch�tzung der Professoren je nach Dienstalter")
lines(x,da22[order(da21)],lty=3)
points(x,da22[order(da21)],pch=16)
lines(x,da23[order(da21)],lty=5)
points(x,da23[order(da21)],pch=17)
legend(1,0.35,c("<5 J","5-12 J",">12 J"),pch=c(1,16,17),lty=c(1,3,5))


###################################################
### chunk number 11:
###################################################
des1_inst<-llbt.design(assis,nitems=8, cov.sel=c("ama"))
ma<-factor(des1_inst$ama)
names(des1_inst)[6:13]<-c("FAKO","VERL","WIFO","KREA","KOOP","EHVE","GEGE","INMO")
res1_inst<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1+(FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1):ma,eliminate=mu:ma,data=des1_inst,family=poisson)
summary(res1_inst)
des2_inst<-llbt.design(profs,nitems=8, cov.sel=c("pma"))
ma<-factor(des2_inst$pma)
names(des2_inst)[6:13]<-c("FAKO","VERL","WIFO","KREA","KOOP","EHVE","GEGE","INMO")
res2_inst<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1+(FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1):ma,eliminate=mu:ma,data=des2_inst,family=poisson)
summary(res2_inst)
coefs1_inst<-rev(res1_inst$coefficients)[1:18]
coefs1_inst<-coefs1_inst[-c(1,10)]
coefs1_inst[c(1,9)]<-0
inst1<-rev(coefs1_inst)[1:8]
inst2<-rev(coefs1_inst[1:8])+inst1
names(inst2)<-names(inst1)
worth(inst1)->inst1;worth(inst2)->inst2
x<-1:8
coefs_inst<-rev(res2_inst$coefficients)[1:18]
coefs_inst<-coefs_inst[-c(1,10)]
coefs_inst[c(1,9)]<-0
inst21<-rev(coefs_inst)[1:8]
inst22<-rev(coefs_inst[1:8])+inst21
names(inst22)<-names(inst21)
worth(inst21)->inst21; worth(inst22)->inst22
x<-1:8


###################################################
### chunk number 12:
###################################################
plot(x,sort(inst1),ylab="Estimates",xlab="Pers�nlichkeitseigenschaften",ylim=c(0,0.35),xaxt="n",type="l")
points(x,sort(inst1),pch=17)
axis(1,at=1:8,labels=names(sort(inst1)))
title("Einsch�tzung der Assistenten je nach Institutsgr��e")
lines(x,inst2[order(inst1)],lty=3)
points(x,inst2[order(inst1)],pch=16)
legend(1,0.35,c("<=6 Mitarb.",">6 Mitarb."),pch=c(17,16),lty=c(1,3))


###################################################
### chunk number 13:
###################################################
plot(x,sort(inst22),ylab="Estimates",xlab="Pers�nlichkeitseigenschaften",lty=3,ylim=c(0,0.35),pch=16,xaxt="n",type="l")
points(x,sort(inst22),pch=16)
axis(1,at=1:8,labels=names(sort(inst22)))
title("Einsch�tzung der Professoren je nach Institutsgr��e")
lines(x,inst21[order(inst22)],lty=1)
points(x,inst21[order(inst22)],pch=17)
legend(1,0.35,c("<=6 Mitarb.",">6 Mitarb."),pch=c(17,16),lty=c(1,3))


###################################################
### chunk number 14:
###################################################
options(width=55)


###################################################
### chunk number 15:
###################################################
##############################
# Laden der verwendeten Pakete
##############################
library(prefmod)
library(lmtest)
library(gnm)
#source("funktion.r")


###################################################
### chunk number 16:
###################################################
##############################
# Laden der Daten inkl. Aufbereitung
##############################
read.table("kap4.csv",sep="\t", header=TRUE)->daten
# DEFINITION DER KOVARIATEN
daten[,1]->ageschl    #Geschlecht der Assistenten
daten[,2]->ada				#Dienstalter der Assistenten
daten[,3]->ama				#Institutsgr��e der Assistenten
daten[,32]->pda				#Dienstalter der Professoren
daten[,33]->pma				#Institutsgr��e der Professoren


###################################################
### chunk number 17:
###################################################
# DATENAUFBEREITUNG
assis<-cbind(daten[,65:92],ageschl, ada, ama) # Mitarbeiter -> Mitarbeiter
profs<-cbind(daten[,34:61],pda, pma)    # Prof -> Mitarbeiter
profs<-(profs[-c(28:80),])    # Zeilenkorrektur


###################################################
### chunk number 18:
###################################################
##############################
# Assistenten - Institutsgr��e
##############################
des1_inst<-llbt.design(assis,nitems=8, cov.sel=c("ama"))
ma<-factor(des1_inst$ama)
names(des1_inst)[6:13]<-c("FAKO","VERL","WIFO","KREA","KOOP","EHVE","GEGE","INMO")
res1_inst<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1+(FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1):ma,eliminate=mu:ma,data=des1_inst,family=poisson)
res1<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1,eliminate=mu:ma,data=des1_inst,family=poisson)
anova(res1,res1_inst)
lrtest(res1,res1_inst)
summary(res1_inst)


###################################################
### chunk number 19:
###################################################
coefs1_inst<-rev(res1_inst$coefficients)[1:18]
coefs1_inst<-coefs1_inst[-c(1,10)]
coefs1_inst[c(1,9)]<-0
inst1<-rev(coefs1_inst)[1:8]
inst2<-rev(coefs1_inst[1:8])+inst1
names(inst2)<-names(inst1)
worth(inst1)->inst1;worth(inst2)->inst2
plot(1:8,sort(inst1),ylab="Estimates",xlab="Pers�nlichkeitseigenschaften",ylim=c(0,0.33),xaxt="n",type="l")
points(1:8,sort(inst1),pch=17)
axis(1,at=1:8,labels=names(sort(inst1)))
title("Einsch�tzung der Assistenten je nach Institutsgr��e")
lines(1:8,inst2[order(inst1)],lty=3)
points(1:8,inst2[order(inst1)],pch=16)
legend(1,0.3,c("<=6 Mitarb.",">6 Mitarb."),pch=c(17,16),lty=c(1,3))
#llbt.plot(res1_inst,wert=FALSE,beschr=c("AMitarbeiter1","AMitarbeiter2"),mltp=2)


###################################################
### chunk number 20:
###################################################
#object
OBJ1inst<-as.matrix(des1_inst[,c("FAKO","VERL","WIFO","KREA","KOOP","EHVE","GEGE","INMO")])
w<-c(1,0,1,0,0,0,0,0)
b<-c(0,0,0,1,1,0,0,1)
a<-c(0,1,0,0,0,0,1,0)
e<-c(0,0,0,0,0,1,0,0)
WISSF1i<-OBJ1inst%*%w
BEGAF1i<-OBJ1inst%*%b
ARBF1i<-OBJ1inst%*%a
EHRL1i<-OBJ1inst%*%e
res1_obji<-gnm(y~WISSF1i+BEGAF1i+ARBF1i+EHRL1i+g1+(WISSF1i+BEGAF1i+ARBF1i+EHRL1i+g1):ma, eliminate=mu:ma, data=des1_inst, family= poisson)
lrtest(res1_inst,res1_obji)


###################################################
### chunk number 21:
###################################################
##############################
# Professoren - Institutsgr��e
##############################
des2_inst<-llbt.design(profs,nitems=8, cov.sel=c("pma"))
ma<-factor(des2_inst$pma)
names(des2_inst)[6:13]<-c("FAKO","VERL","WIFO","KREA","KOOP","EHVE","GEGE","INMO")
res2_inst<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1+(FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1):ma,eliminate=mu:ma,data=des2_inst,family=poisson)
res2<-gnm(y~FAKO+VERL+WIFO+KREA+KOOP+EHVE+GEGE+INMO+g1,eliminate=mu:ma,data=des2_inst,family=poisson)
anova(res2,res2_inst)
summary(res2_inst)


###################################################
### chunk number 22:
###################################################
coefs_inst<-rev(res2_inst$coefficients)[1:18]
coefs_inst<-coefs_inst[-c(1,10)]
coefs_inst[c(1,9)]<-0
inst21<-rev(coefs_inst)[1:8]
inst22<-rev(coefs_inst[1:8])+inst21
names(inst22)<-names(inst21)
worth(inst21)->inst21; worth(inst22)->inst22
#plot(sort(inst22),inst21[order(inst22)])
x<-1:8
plot(x,sort(inst22),ylab="Estimates",xlab="Pers�nlichkeitseigenschaften",lty=3,ylim=c(0,0.35),pch=16,xaxt="n",type="l")
points(x,sort(inst22),pch=16)
axis(1,at=1:8,labels=names(sort(inst22)))
title("Einsch�tzung der Professoren je nach Institutsgr��e")
lines(x,inst21[order(inst22)],lty=1)
points(x,inst21[order(inst22)],pch=17)
legend(1,0.35,c("<=6 Mitarb.",">6 Mitarb."),pch=c(17,16),lty=c(1,3))
#llbt.plot(res2_inst,wert=FALSE,beschr=c("PMitarbeiter1","PMitarbeiter2"),mltp=2)


###################################################
### chunk number 23:
###################################################
OBJ2inst<-as.matrix(des2_inst[,c("FAKO","VERL","WIFO","KREA","KOOP","EHVE","GEGE","INMO")])
WISSF2i<-OBJ2inst%*%w
BEGAF2i<-OBJ2inst%*%b
ARBF2i<-OBJ2inst%*%a
EHRL2i<-OBJ2inst%*%e
res2_obji<-gnm(y~WISSF2i+BEGAF2i+ARBF2i+EHRL2i+g1+(WISSF2i+BEGAF2i+ARBF2i+EHRL2i+g1):ma, eliminate=mu:ma, data=des2_inst, family= poisson)
anova(res2_inst,res2_obji)


###################################################
### chunk number 24:
###################################################
options(width=80)


