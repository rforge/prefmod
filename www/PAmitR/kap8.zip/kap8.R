##Daten aus CSV-Datei einlesen
Daten_nurKenner<-na.omit(read.csv2("kap8.csv", header=TRUE))
##Paarvergleiche der Risikodimensionen und Subjektkovariate "Experte-Laie" einlesen
#? verlustrisiko_exp<-Daten_nurKenner[,c(3:8,26)]
verlustrisiko_exp<-Daten_nurKenner[,c(6,7,3,8,4,5,26)]  #?????
verlustrisiko_exp[,4:6]<-verlustrisiko_exp[,4:6]*-1

gewinnrisiko_exp<-Daten_nurKenner[,c(15:20,26)]
inforisiko_exp<-Daten_nurKenner[,c(9:14,26)]

##Designmatrix Verlustrisiko erstellen
des.verlust_exp<-llbt.design(verlustrisiko_exp, nitems=4, cov.sel=c("Finanz1.Neu"))
exp_verlust<-factor(des.verlust_exp$Finanz1.Neu)
names(des.verlust_exp)[5:8]<-c("Aktien", "Immobilien", "Rohstoff", "Waehrung")

##Designmatrix Gewinnrisiko erstellen
des.gewinn_exp<-llbt.design(gewinnrisiko_exp, nitems=4, , cov.sel=c("Finanz1.Neu"))
exp_gewinn<-factor(des.gewinn_exp$Finanz1.Neu)
names(des.gewinn_exp)[5:8]<-c("Aktien", "Immobilien", "Rohstoff", "Waehrung")

##Designmatrix Informationsrisiko erstellen
des.info_exp<-llbt.design(inforisiko_exp, nitems=4, cov.sel=c("Finanz1.Neu"))
exp_info<-factor(des.info_exp$Finanz1.Neu)
names(des.info_exp)[5:8]<-c("Aktien", "Immobilien", "Rohstoff", "Waehrung")

##Kopf der Designmatrizen ausgeben
head(des.verlust_exp)
head(des.gewinn_exp)
head(des.info_exp)

##Modelle ohne Kovariate berechnen
res.verlust_exp<-gnm(y~Aktien+Immobilien+Rohstoff+Waehrung, family=poisson, eliminate=mu:exp_verlust,data=des.verlust_exp)
res.gewinn_exp<-gnm(y~Aktien+Immobilien+Rohstoff+Waehrung,family=poisson, eliminate=mu:exp_gewinn,data=des.gewinn_exp)
res.info_exp<-gnm(y~Aktien+Immobilien+Rohstoff+Waehrung, family=poisson,eliminate=mu:exp_info,data=des.info_exp)
##Modelle mit Kovariate "Experte-Laie" berechnen

res.verlust_exp_vgl<-gnm(y~Aktien+Immobilien+Rohstoff+Waehrung+(Aktien+Immobilien+Rohstoff+Waehrung):exp_verlust,family=poisson, eliminate=mu:exp_verlust,data=des.verlust_exp)
res.gewinn_exp_vgl<-gnm(y~Aktien+Immobilien+Rohstoff+Waehrung+(Aktien+Immobilien+Rohstoff+Waehrung):exp_gewinn,family=poisson, eliminate=mu:exp_gewinn,data=des.gewinn_exp)
res.info_exp_vgl<-gnm(y~Aktien+Immobilien+Rohstoff+Waehrung+(Aktien+Immobilien+Rohstoff+Waehrung):exp_info,family=poisson, eliminate=mu:exp_info,data=des.info_exp)

##Summaries und ANOVA der Modelle f�r das Verlustrisiko ausgeben,�berpr�fen ob Verbesserung signifikant
summary(res.verlust_exp)
summary(res.verlust_exp_vgl)
anova(res.verlust_exp,res.verlust_exp_vgl)
dev_verlust_exp_vgl<-round(res.verlust_exp_vgl$deviance,digits=4)
df_verlust_exp_vgl<-res.verlust_exp_vgl$df.residual
prob_verlust_exp_vgl<-1-pchisq(dev_verlust_exp_vgl,df_verlust_exp_vgl)
print(prob_verlust_exp_vgl)

##Summaries und ANOVA der Modelle f�r das Gewinnrisiko ausgeben,�berpr�fen ob Verbesserung signifikant
summary(res.gewinn_exp)
summary(res.gewinn_exp_vgl)
anova(res.gewinn_exp,res.gewinn_exp_vgl)
dev_gewinn_exp_vgl<-round(res.gewinn_exp_vgl$deviance,digits=4)
df_gewinn_exp_vgl<-res.gewinn_exp_vgl$df.residual
prob_gewinn_exp_vgl<-1-pchisq(dev_gewinn_exp_vgl,df_gewinn_exp_vgl)
print(prob_gewinn_exp_vgl)
##Summaries und ANOVA der Modelle f�r das Informationsrisiko ausgeben,�berpr�fen ob Verbesserung signifikant
summary(res.info_exp)
summary(res.info_exp_vgl)
anova(res.info_exp,res.info_exp_vgl)
dev_info_exp_vgl<-round(res.info_exp_vgl$deviance,digits=4)
df_info_exp_vgl<-res.info_exp_vgl$df.residual
prob_info_exp_vgl<-1-pchisq(dev_info_exp_vgl,df_info_exp_vgl)
print(prob_info_exp_vgl)

##Lambdas aus den Koeffizienten auslesen und Worth-Parameter errechnen

##Verlustrisiko der Modelle mit Kovariaten
res.verlust_exp_vgl$coefficients[16]<-0
koord_verl_exp_ja<-res.verlust_exp_vgl$coefficients[13:16]  ## Koeffizienten der Experten
worth_verl_exp_ja<-(exp(2 * koord_verl_exp_ja)/(sum(exp(2 * koord_verl_exp_ja))))  ##Worth-parameter der Experten
res.verlust_exp_vgl$coefficients[20]<-0
koord_verl_exp_nein<-res.verlust_exp_vgl$coefficients[17:20]+res.verlust_exp_vgl$coefficients[13:16] ##Koeffizienten der Laien
worth_verl_exp_nein<-(exp(2 * koord_verl_exp_nein)/(sum(exp(2 * koord_verl_exp_nein))))  ##Worth-Parameter der Laien
##Ausgabe der Worth-ParameterVerlustrisiko
worth_verl_exp_ja
worth_verl_exp_nein

##Gewinnrisiko der Modelle mit Kovariaten
res.gewinn_exp_vgl$coefficients[16]<-0
koord_gewinn_exp_ja<-res.gewinn_exp_vgl$coefficients[13:16]  ##Koeffizienten der Experten
worth_gewinn_exp_ja<-(exp(2 * koord_gewinn_exp_ja)/(sum(exp(2 * koord_gewinn_exp_ja))))  ##worth-parameter der Experten
res.gewinn_exp_vgl$coefficients[20]<-0
koord_gewinn_exp_nein<-res.gewinn_exp_vgl$coefficients[17:20]+res.gewinn_exp_vgl$coefficients[13:16] ##Koeffizienten der Laien
worth_gewinn_exp_nein<-(exp(2 * koord_gewinn_exp_nein)/(sum(exp(2 * koord_gewinn_exp_nein))))  ##worth-parameter der Laien
##Ausgabe der Worth-Parameter Gewinnrisiko
worth_gewinn_exp_ja
worth_gewinn_exp_nein

##Inforisiko
res.info_exp_vgl$coefficients[16]<-0
koord_info_exp_ja<-res.info_exp_vgl$coefficients[13:16]  ## Koeffizienten der Experten
worth_info_exp_ja<-(exp(2 * koord_info_exp_ja)/(sum(exp(2 * koord_info_exp_ja))))  ##worth-parameter der Experten
res.info_exp_vgl$coefficients[20]<-0
koord_info_exp_nein<-res.info_exp_vgl$coefficients[17:20]+res.info_exp_vgl$coefficients[13:16] ##Koeffizienten der Laien
worth_info_exp_nein<-(exp(2 * koord_info_exp_nein)/(sum(exp(2 * koord_info_exp_nein))))   ##worth-parameter der Experten
##Ausgabe der Worth-Parameter Informationsrisiko
worth_info_exp_ja
worth_info_exp_nein


## Grafischen Vergleich aus Basis der Koeffizienten anzeigen, Verlustrisiko
## plotpref definieren
plotpref<-function(x, main="Verlustrisiko", xlab="Experte-Laie", ylab="Worth")
{
     x<-x[order(x$group,-x$estimate),]
     group<-factor(x$group, ordered=TRUE)
     tab<-table(group)
     adj<-1/nchar(as.character(x$objects))
     hadj0<-rep(c(0,1),ceiling(tab[1]/2))
     hadj1<-ifelse(hadj0==0,-1,1)
     hadj<-adj*hadj1+hadj0
     x<-cbind(x,hadj)
     p<-qplot(group, estimate,
                #colour=objects, size=4, # coment 1m
                data=x, main=main, xlab=xlab, ylab=ylab,ylim=c(0,1))
     p$legend.position="none"
     psize<-geom_point(size=4,colour="black") # comment 2
     ann<-geom_text(aes(x=group,y=estimate,label=objects, colour="black"),
             hjust=hadj,size=4)
     print(p+psize+ann)
}
##Koordinaten und Objektnamen zuweisen,plotten
estimate<-c(worth_verl_exp_ja,worth_verl_exp_nein)
group<-c(rep("Experte",4),rep("Laie",4))
objects<-c("Aktien","Immo","Rohstoff","W�hrung","Aktien","Immo","Rohstoff","W�hrung")
x<-data.frame(estimate,objects,group)
plotpref(x)

## Grafischen Vergleich anzeigen, Gewinnrisiko
## plotpref definieren
plotpref<-function(x, main="Gewinnrisiko", xlab="Experte-Laie", ylab="Worth")
{
     x<-x[order(x$group,-x$estimate),]
     group<-factor(x$group, ordered=TRUE)
     tab<-table(group)
     adj<-1/nchar(as.character(x$objects))
     hadj0<-rep(c(0,1),ceiling(tab[1]/2))
     hadj1<-ifelse(hadj0==0,-1,1)
     hadj<-adj*hadj1+hadj0
     x<-cbind(x,hadj)
     p<-qplot(group, estimate,
                #colour=objects, size=4, # coment 1m
                data=x, main=main, xlab=xlab, ylab=ylab,ylim=c(0,1))
     p$legend.position="none"
     psize<-geom_point(size=4,colour="black") # comment 2
     ann<-geom_text(aes(x=group,y=estimate,label=objects, colour="black"),
             hjust=hadj,size=4)
     print(p+psize+ann)
}
##Koordinaten und Objektnamen zuweisen, plotten
estimate<-c(worth_gewinn_exp_ja,worth_gewinn_exp_nein)
group<-c(rep("Experte",4),rep("Laie",4))
objects<-c("Aktien","Immo","Rohstoff","W�hrung","Aktien","Immo","Rohstoff","W�hrung")
x<-data.frame(estimate,objects,group)
plotpref(x)

## Grafischen Vergleich anzeigen, Informationsrisiko
## plotpref definieren
plotpref<-function(x, main="Informationsrisiko", xlab="Experte-Laie", ylab="Worth")
{
     x<-x[order(x$group,-x$estimate),]
     group<-factor(x$group, ordered=TRUE)
     tab<-table(group)
     adj<-1/nchar(as.character(x$objects))
     hadj0<-rep(c(0,1),ceiling(tab[1]/2))
     hadj1<-ifelse(hadj0==0,-1,1)
     hadj<-adj*hadj1+hadj0
     x<-cbind(x,hadj)
     p<-qplot(group, estimate,
                #colour=objects, size=4, # coment 1m
                data=x, main=main, xlab=xlab, ylab=ylab,ylim=c(0,1))
     p$legend.position="none"
     psize<-geom_point(size=4,colour="black") # comment 2
     ann<-geom_text(aes(x=group,y=estimate,label=objects, colour="black"),
             hjust=hadj,size=4)
     print(p+psize+ann)
}
##Koordinaten und Objektnamen zuweisen, plotten
estimate<-c(estimate<-c(worth_info_exp_ja,worth_info_exp_nein))
group<-c(rep("Experte",4),rep("Laie",4))
objects<-c("Aktien","Immo","Rohstoff","W�hrung","Aktien","Immo","Rohstoff","W�hrung")
x<-data.frame(estimate,objects,group)
plotpref(x)

##Plot alle Risikoarten
plotpref<-function(x, main="Vergleich alle Risikodimensionen", xlab="Experte-Laie", ylab="Worth")
{
     x<-x[order(x$group,-x$estimate),]
     group<-factor(x$group, ordered=TRUE)
     tab<-table(group)
     adj<-1/nchar(as.character(x$objects))
     hadj0<-rep(c(0,1),ceiling(tab[1]/2))
     hadj1<-ifelse(hadj0==0,-1,1)
     hadj<-adj*hadj1+hadj0
     x<-cbind(x,hadj)
     p<-qplot(group, estimate,
                #colour=objects, size=4, # coment 1m
                data=x, main=main, xlab=xlab, ylab=ylab,ylim=c(0,1))
     p$legend.position="none"
     psize<-geom_point(size=4,colour="black") # comment 2
     ann<-geom_text(aes(x=group,y=estimate,label=objects, colour="black"),
             hjust=hadj,size=4)
     print(p+psize+ann)
}

estimate<-c(worth_verl_exp_ja, worth_verl_exp_nein, worth_gewinn_exp_ja, worth_gewinn_exp_nein, worth_info_exp_ja, worth_info_exp_nein)
group<-c(rep("Verlustr. Experte",4),rep("Verlustr. Laie",4),rep("Gewinnr. Experte",4),rep("Gewinnr. Laie",4),rep("Infor. Experte",4),rep("Infor. Laie",4))
objects<-c("Aktien","Immo","Rohstoff","W�hrung","Aktien","Immo","Rohstoff","W�hrung","Aktien","Immo","Rohstoff","W�hrung","Aktien","Immo","Rohstoff","W�hrung","Aktien","Immo","Rohstoff","W�hrung","Aktien","Immo","Rohstoff","W�hrung")
x<-data.frame(estimate,objects,group)
plotpref(x)

#########################################################
##Plot nach Fonds - Risikowahrnehmung nach Experten-Laien
#########################################################

##Koordinaten Aktienfonds �bertragen (Worth-Parameter, Koeffizienten asgeblendet)
aktien_profil_experten<-c(worth_info_exp_ja[1],worth_gewinn_exp_ja[1],worth_verl_exp_ja[1])
aktien_profil_laien<-c(worth_info_exp_nein[1],worth_gewinn_exp_nein[1],worth_verl_exp_nein[1])
##aktien_profil_laien<-c(res.info_exp_vgl$coefficients[17]+res.info_exp_vgl$coefficients[13],res.gewinn_exp_vgl$coefficients[17]+res.gewinn_exp_vgl$coefficients[13],res.verlust_exp_vgl$coefficients[17]+res.verlust_exp_vgl$coefficients[13])
##aktien_profil_experten<-c(res.info_exp_vgl$coefficients[13],res.gewinn_exp_vgl$coefficients[13],res.verlust_exp_vgl$coefficients[13])
names(aktien_profil_laien)<-c("Informationsrisiko","Gewinnrisiko","Verlustrisiko")
names(aktien_profil_experten)<-c("Informationsrisiko","Gewinnrisiko","Verlustrisiko")
##Koordinaten Immobilienfonds �bertragen  Worth-Parameter, Koeffizienten asgeblendet)
immo_profil_experten<-c(worth_info_exp_ja[2],worth_gewinn_exp_ja[2],worth_verl_exp_ja[2])
immo_profil_laien<-c(worth_info_exp_nein[2],worth_gewinn_exp_nein[2],worth_verl_exp_nein[2])
##immo_profil_laien<-c(res.info_exp_vgl$coefficients[18]+res.info_exp_vgl$coefficients[14],res.gewinn_exp_vgl$coefficients[18]+res.gewinn_exp_vgl$coefficients[14],res.verlust_exp_vgl$coefficients[18]+res.verlust_exp_vgl$coefficients[14])
##immo_profil_experten<-c(res.info_exp_vgl$coefficients[14],res.gewinn_exp_vgl$coefficients[14],res.verlust_exp_vgl$coefficients[14])
names(immo_profil_laien)<-c("Informationsrisiko","Gewinnrisiko","Verlustrisiko")
names(immo_profil_experten)<-c("Informationsrisiko","Gewinnrisiko","Verlustrisiko")
##Koordinaten Rohstofffonds �bertragen  Worth-Parameter, Koeffizienten asgeblendet)
rohstoff_profil_experten<-c(worth_info_exp_ja[3],worth_gewinn_exp_ja[3],worth_verl_exp_ja[3])
rohstoff_profil_laien<-c(worth_info_exp_nein[3],worth_gewinn_exp_nein[3],worth_verl_exp_nein[3])
##rohstoff_profil_laien<-c(res.info_exp_vgl$coefficients[19]+res.info_exp_vgl$coefficients[15],res.gewinn_exp_vgl$coefficients[19]+res.gewinn_exp_vgl$coefficients[19],res.verlust_exp_vgl$coefficients[19]+res.verlust_exp_vgl$coefficients[15])
##rohstoff_profil_experten<-c(res.info_exp_vgl$coefficients[15],res.gewinn_exp_vgl$coefficients[15],res.verlust_exp_vgl$coefficients[15])
names(rohstoff_profil_laien)<-c("Informationsrisiko","Gewinnrisiko","Verlustrisiko")
names(rohstoff_profil_experten)<-c("Informationsrisiko","Gewinnrisiko","Verlustrisiko")
##Koordinaten W�hrungsfonds �bertragen
w�hrung_profil_experten<-c(worth_info_exp_ja[4],worth_gewinn_exp_ja[4],worth_verl_exp_ja[4])
w�hrung_profil_laien<-c(worth_info_exp_nein[4],worth_gewinn_exp_nein[4],worth_verl_exp_nein[4])
##w�hrung_profil_laien<-c(res.info_exp_vgl$coefficients[20]+res.info_exp_vgl$coefficients[16],res.gewinn_exp_vgl$coefficients[20]+res.gewinn_exp_vgl$coefficients[16],res.verlust_exp_vgl$coefficients[20]+res.verlust_exp_vgl$coefficients[16])
##w�hrung_profil_experten<-c(res.info_exp_vgl$coefficients[16],res.gewinn_exp_vgl$coefficients[16],res.verlust_exp_vgl$coefficients[16])
names(w�hrung_profil_laien)<-c("Informationsrisiko","Gewinnrisiko","Verlustrisiko")
names(w�hrung_profil_experten)<-c("Informationsrisiko","Gewinnrisiko","Verlustrisiko")
